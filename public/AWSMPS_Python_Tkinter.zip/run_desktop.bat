@echo off
title Automotive Work Study & Manpower Planning System (AWSMPS) - Tkinter
echo ====================================================================
echo  Automotive Work Study & Manpower Planning System (AWSMPS)
echo  Desktop Application - Python Tkinter Edition
echo  Zero-SQL SQLite3 Auto-Provisioning Engine
echo ====================================================================
echo.
echo Checking Python installation...
python --version >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo Python is not detected in your PATH. Trying 'python3'...
    python3 --version >nul 2>&1
    if %ERRORLEVEL% NEQ 0 (
        echo [ERROR] Python is not installed or not in PATH!
        echo Please download and install Python from https://www.python.org/downloads/
        echo (Ensure you check 'Add Python to PATH' during installation)
        echo.
        pause
        exit /b 1
    )
    python3 awsmps_desktop.py
) else (
    python awsmps_desktop.py
)
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo Application exited with code %ERRORLEVEL%.
    pause
)
