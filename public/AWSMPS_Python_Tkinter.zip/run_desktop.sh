#!/usr/bin/env bash
echo "===================================================================="
echo "Automotive Work Study & Manpower Planning System (AWSMPS) - Tkinter"
echo "Zero-SQL SQLite3 Auto-Provisioning Engine"
echo "===================================================================="
if command -v python3 &>/dev/null; then
    python3 awsmps_desktop.py
elif command -v python &>/dev/null; then
    python awsmps_desktop.py
else
    echo "[ERROR] Python 3 is not found in PATH."
    echo "Please install Python 3 with Tkinter support."
    exit 1
fi
