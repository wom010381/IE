<?php
namespace App\Services;

class CalculationService {
    public static function calculateTaktTime(int $netSeconds, int $demandUnits): float {
        if ($demandUnits <= 0) return 0.0;
        return round($netSeconds / $demandUnits, 2);
    }

    public static function calculateTheoreticalHeadcount(float $totalWorkContent, float $targetCycleTime): int {
        if ($targetCycleTime <= 0) return 0;
        return (int) ceil($totalWorkContent / $targetCycleTime);
    }

    public static function calculateStandardTimeFraction(float $normalTime, float $allowanceFraction): float {
        if ($allowanceFraction >= 1.0) {
            throw new \InvalidArgumentException("Allowance fraction must be less than 1.0");
        }
        return round($normalTime / (1.0 - $allowanceFraction), 2);
    }

    public static function calculateStandardTimePercent(float $normalTime, float $allowanceFraction): float {
        return round($normalTime * (1.0 + $allowanceFraction), 2);
    }

    public static function calculateLineBalanceEfficiency(float $totalWorkContent, int $stationCount, float $maxStationTime): float {
        if ($stationCount <= 0 || $maxStationTime <= 0) return 0.0;
        return round(($totalWorkContent / ($stationCount * $maxStationTime)) * 100, 1);
    }
}
