<?php
namespace App\Models;

use PDO;
use PDOException;

/**
 * Self-Bootstrapping and Self-Healing Database Manager
 * Incorporates ALL schema creation, column migrations, and demonstration data directly into PHP code.
 * Zero manual SQL editing or import required.
 */
class Database {
    private static ?PDO $instance = null;

    public static function getConnection(): PDO {
        if (self::$instance === null) {
            require_once __DIR__ . '/../../config/database.php';
            
            // 1. Ensure MySQL server is reachable and database exists
            try {
                $rootDsn = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";charset=" . DB_CHARSET;
                $rootPdo = new PDO($rootDsn, DB_USER, DB_PASS, [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                ]);
                $rootPdo->exec("CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            } catch (PDOException $e) {
                die("<div style='font-family:sans-serif;padding:20px;background:#fee2e2;color:#991b1b;border-radius:8px;'>
                    <h3>MySQL Connection Failed</h3>
                    <p>Please ensure MySQL is started in the XAMPP Control Panel.</p>
                    <p><strong>Error:</strong> " . htmlspecialchars($e->getMessage()) . "</p>
                </div>");
            }

            // 2. Connect to the awsmps database
            try {
                $dsn = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
                self::$instance = new PDO($dsn, DB_USER, DB_PASS, [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]);

                // 3. Auto-heal and ensure all columns and data exist!
                self::autoHealSchema(self::$instance);

            } catch (PDOException $e) {
                die("AWSMPS Database Error: " . htmlspecialchars($e->getMessage()));
            }
        }
        return self::$instance;
    }

    /**
     * Checks all tables and columns, automatically rebuilds any obsolete legacy tables!
     */
    public static function autoHealSchema(PDO $pdo): void {
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 0;");

        // 1. Detect if an old incompatible products or task_elements table exists
        $hasProducts = ($pdo->query("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = '" . DB_NAME . "' AND table_name = 'products'")->fetchColumn() > 0);
        $hasProductNameCol = false;
        if ($hasProducts) {
            $stmt = $pdo->query("SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = '" . DB_NAME . "' AND table_name = 'products' AND column_name = 'product_name'");
            $hasProductNameCol = ($stmt->fetchColumn() > 0);
        }

        $hasTaskElements = ($pdo->query("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = '" . DB_NAME . "' AND table_name = 'task_elements'")->fetchColumn() > 0);
        $hasSeqOrderCol = false;
        if ($hasTaskElements) {
            $stmt = $pdo->query("SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = '" . DB_NAME . "' AND table_name = 'task_elements' AND column_name = 'sequence_order'");
            $hasSeqOrderCol = ($stmt->fetchColumn() > 0);
        }

        // If old tables exist without required columns, drop them to ensure clean migration!
        if (($hasProducts && !$hasProductNameCol) || ($hasTaskElements && !$hasSeqOrderCol)) {
            $pdo->exec("DROP TABLE IF EXISTS `production_verifications`, `standard_work_steps`, `standard_work_documents`, `operator_skills`, `workload_assignments`, `operator_positions`, `element_time_observations`, `task_elements`, `video_observations`, `video_files`, `manpower_plans`, `work_study_projects`, `products`, `users`, `audit_logs`;");
        }

        // 2. Ensure all base tables exist
        self::ensureTablesExist($pdo);

        // 3. Check and auto-add any missing columns
        self::ensureColumnExists($pdo, 'products', 'product_name', 'VARCHAR(200) NOT NULL AFTER `model_number`');
        self::ensureColumnExists($pdo, 'task_elements', 'sequence_order', 'INT NOT NULL DEFAULT 1 AFTER `work_description`');
        self::ensureColumnExists($pdo, 'task_elements', 'standard_time', 'DECIMAL(8,2) NOT NULL DEFAULT 36.00');
        self::ensureColumnExists($pdo, 'task_elements', 'assigned_position', 'VARCHAR(50) DEFAULT "OP-01"');

        // 4. Check if demo data exists. If any table is empty, auto-seed it safely!
        try {
            $count = $pdo->query("SELECT COUNT(*) FROM `products`")->fetchColumn();
            if ($count == 0) {
                self::seedDemoData($pdo);
            }
        } catch (\Exception $e) {
            // Drop and clean rebuild if column mismatch occurred
            $pdo->exec("DROP TABLE IF EXISTS `production_verifications`, `standard_work_steps`, `standard_work_documents`, `operator_skills`, `workload_assignments`, `operator_positions`, `element_time_observations`, `task_elements`, `video_observations`, `video_files`, `manpower_plans`, `work_study_projects`, `products`, `users`, `audit_logs`;");
            self::ensureTablesExist($pdo);
            self::seedDemoData($pdo);
        }

        $pdo->exec("SET FOREIGN_KEY_CHECKS = 1;");
    }

    private static function ensureColumnExists(PDO $pdo, string $table, string $column, string $definition): void {
        try {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = ? AND table_name = ? AND column_name = ?");
            $stmt->execute([DB_NAME, $table, $column]);
            if ($stmt->fetchColumn() == 0) {
                // Column does not exist! Add it automatically!
                $pdo->exec("ALTER TABLE `{$table}` ADD COLUMN `{$column}` {$definition};");
            }
        } catch (\Exception $e) {
            // Silently ignore if table not ready
        }
    }

    public static function ensureTablesExist(PDO $pdo): void {
        $ddlStatements = [
            "CREATE TABLE IF NOT EXISTS `users` (
              `id` VARCHAR(36) PRIMARY KEY,
              `employee_id` VARCHAR(50) NOT NULL UNIQUE,
              `full_name` VARCHAR(150) NOT NULL,
              `email` VARCHAR(150) NOT NULL UNIQUE,
              `password_hash` VARCHAR(255) NOT NULL,
              `role` ENUM('admin', 'engineer', 'reviewer', 'approver', 'line_leader', 'viewer') NOT NULL,
              `department` VARCHAR(100) NOT NULL,
              `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB;",

            "CREATE TABLE IF NOT EXISTS `products` (
              `id` VARCHAR(36) PRIMARY KEY,
              `model_number` VARCHAR(100) NOT NULL,
              `product_name` VARCHAR(200) NOT NULL,
              `part_number` VARCHAR(100) NOT NULL,
              `revision` VARCHAR(30) NOT NULL,
              `customer` VARCHAR(150) NOT NULL,
              `vehicle_model` VARCHAR(150) NOT NULL,
              `harness_type` VARCHAR(150) NOT NULL,
              `housing_references` TEXT,
              `circuit_count` INT NOT NULL DEFAULT 0,
              `process_name` VARCHAR(200) NOT NULL,
              `assembly_line` VARCHAR(100) NOT NULL,
              `production_method` VARCHAR(150) NOT NULL,
              `quality_checkpoints` TEXT,
              `effective_date` DATE NOT NULL,
              `status` ENUM('Draft', 'Active', 'On Hold', 'Obsolete') DEFAULT 'Draft',
              `current_work_study_rev` VARCHAR(50),
              `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB;",

            "CREATE TABLE IF NOT EXISTS `work_study_projects` (
              `id` VARCHAR(36) PRIMARY KEY,
              `product_id` VARCHAR(36) NOT NULL,
              `product_revision` VARCHAR(30) NOT NULL,
              `study_purpose` TEXT NOT NULL,
              `customer_requirement` TEXT,
              `assigned_engineer` VARCHAR(150) NOT NULL,
              `reviewer` VARCHAR(150),
              `approver` VARCHAR(150),
              `start_date` DATE NOT NULL,
              `target_completion_date` DATE NOT NULL,
              `expected_shift_quantity` INT NOT NULL DEFAULT 700,
              `planned_line` VARCHAR(100) NOT NULL,
              `target_cycle_time` DECIMAL(8,2) NOT NULL DEFAULT 36.00,
              `available_time_per_shift` INT NOT NULL DEFAULT 25200,
              `planned_shifts` INT NOT NULL DEFAULT 2,
              `current_manpower` INT NOT NULL DEFAULT 6,
              `status` VARCHAR(50) DEFAULT 'Draft',
              `notes` TEXT,
              `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB;",

            "CREATE TABLE IF NOT EXISTS `task_elements` (
              `id` VARCHAR(36) PRIMARY KEY,
              `project_id` VARCHAR(36) NOT NULL,
              `element_code` VARCHAR(50) NOT NULL,
              `operation_name` VARCHAR(200) NOT NULL,
              `work_description` TEXT NOT NULL,
              `sequence_order` INT NOT NULL DEFAULT 1,
              `workstation` VARCHAR(100) NOT NULL,
              `tools` VARCHAR(255),
              `components` VARCHAR(255),
              `category` VARCHAR(50) DEFAULT 'Manual',
              `safety_considerations` TEXT,
              `quality_checks` TEXT,
              `performance_rating` DECIMAL(5,2) DEFAULT 1.00,
              `standard_time` DECIMAL(8,2) NOT NULL DEFAULT 36.00,
              `assigned_position` VARCHAR(50) DEFAULT 'OP-01'
            ) ENGINE=InnoDB;",

            "CREATE TABLE IF NOT EXISTS `operator_positions` (
              `id` VARCHAR(36) PRIMARY KEY,
              `position_number` VARCHAR(50) NOT NULL,
              `position_name` VARCHAR(200) NOT NULL,
              `workstation` VARCHAR(100) NOT NULL,
              `target_cycle_time` DECIMAL(8,2) NOT NULL DEFAULT 36.00,
              `required_skills` TEXT,
              `quality_gate` TEXT
            ) ENGINE=InnoDB;",

            "CREATE TABLE IF NOT EXISTS `manpower_plans` (
              `id` VARCHAR(36) PRIMARY KEY,
              `project_id` VARCHAR(36) NOT NULL,
              `net_available_time` INT NOT NULL DEFAULT 25200,
              `required_quantity` INT NOT NULL DEFAULT 700,
              `takt_time` DECIMAL(8,2) NOT NULL DEFAULT 36.00,
              `target_cycle_time` DECIMAL(8,2) NOT NULL DEFAULT 36.00,
              `total_work_content` DECIMAL(8,2) NOT NULL DEFAULT 180.00,
              `theoretical_min_operators` INT NOT NULL DEFAULT 5,
              `proposed_assigned_operators` INT NOT NULL DEFAULT 5,
              `line_efficiency_factor` DECIMAL(5,2) DEFAULT 0.92,
              `status` VARCHAR(50) DEFAULT 'Validated',
              `approval_date` DATE,
              `approved_by` VARCHAR(150),
              `assumptions` TEXT
            ) ENGINE=InnoDB;",

            "CREATE TABLE IF NOT EXISTS `operator_skills` (
              `id` VARCHAR(36) PRIMARY KEY,
              `operator_id` VARCHAR(50) NOT NULL,
              `operator_name` VARCHAR(150) NOT NULL,
              `assigned_line` VARCHAR(100) NOT NULL,
              `shift` VARCHAR(50) NOT NULL,
              `workstation` VARCHAR(100) NOT NULL,
              `skill_name` VARCHAR(200) NOT NULL,
              `skill_level` VARCHAR(50) NOT NULL,
              `training_status` VARCHAR(50) NOT NULL,
              `qualification_date` DATE
            ) ENGINE=InnoDB;",

            "CREATE TABLE IF NOT EXISTS `production_verifications` (
              `id` VARCHAR(36) PRIMARY KEY,
              `shift_date` DATE NOT NULL,
              `shift_name` VARCHAR(50) NOT NULL,
              `planned_output` INT NOT NULL DEFAULT 700,
              `actual_output` INT NOT NULL,
              `output_achievement_percent` DECIMAL(6,2) NOT NULL,
              `target_cycle_time` DECIMAL(8,2) NOT NULL DEFAULT 36.00,
              `actual_cycle_time` DECIMAL(8,2) NOT NULL,
              `cycle_time_gap` DECIMAL(6,2) NOT NULL,
              `planned_manpower` INT NOT NULL DEFAULT 5,
              `actual_manpower` INT NOT NULL DEFAULT 5,
              `downtime_minutes` DECIMAL(6,2) DEFAULT 0,
              `supervisor_remarks` TEXT
            ) ENGINE=InnoDB;",

            "CREATE TABLE IF NOT EXISTS `audit_logs` (
              `id` VARCHAR(36) PRIMARY KEY,
              `timestamp` DATETIME DEFAULT CURRENT_TIMESTAMP,
              `user_name` VARCHAR(150) NOT NULL,
              `user_role` VARCHAR(50) NOT NULL,
              `action` VARCHAR(150) NOT NULL,
              `module` VARCHAR(100) NOT NULL,
              `details` TEXT
            ) ENGINE=InnoDB;"
        ];

        foreach ($ddlStatements as $sql) {
            $pdo->exec($sql);
        }
    }

    public static function seedDemoData(PDO $pdo): void {
        $pdo->exec("DELETE FROM `products`;");
        $pdo->exec("INSERT INTO `products` (`id`, `model_number`, `product_name`, `part_number`, `revision`, `customer`, `vehicle_model`, `harness_type`, `housing_references`, `circuit_count`, `process_name`, `assembly_line`, `production_method`, `quality_checkpoints`, `effective_date`, `status`, `current_work_study_rev`) VALUES
            ('prod-01', 'WH-ENG-8402', 'Engine Main Wiring Harness (Hybrid V6)', '82111-42K80', 'Rev C.1', 'Toyota Global / TNGA-K', 'Camry HEV 2026', 'Engine Multi-Branch High & Low Voltage Mix', '48-Way Sealed ECU Housing (90980-12543), 24-Way Fuse Box Connector', 74, 'Sub-Assembly, Insertion, Taping & Continuity Testing', 'Harness Assembly Line 4 (Alpha)', 'Progressive Conveyor Board with Dual Jigs', 'Push-Pull-Push Terminal Lock, Dual Hinge Snap, 100% Continuity', '2026-08-15', 'Active', 'WSR-2026-04'),
            ('prod-02', 'WH-BCM-3190', 'Body Control Module Harness (Cockpit IP)', '82120-0E150', 'Rev B.2', 'Ford Motor Co. / Global C2', 'Escape HEV 2026', 'Instrument Panel & Center Console Interconnect', '32-Way Green BCM Header, 16-Way OBD-II Diagnostic', 58, 'Wire Routing, Joint Splice Heat Shrink, Connector Insertion', 'Harness Assembly Line 2 (Beta)', 'Rotary Carousel Board', 'Cavity Seal Integrity, Splice Crimp Micrometer Check', '2026-05-10', 'Active', 'WSR-2026-02');");

        $pdo->exec("DELETE FROM `work_study_projects`;");
        $pdo->exec("INSERT INTO `work_study_projects` (`id`, `product_id`, `product_revision`, `study_purpose`, `customer_requirement`, `assigned_engineer`, `reviewer`, `approver`, `start_date`, `target_completion_date`, `expected_shift_quantity`, `planned_line`, `target_cycle_time`, `available_time_per_shift`, `planned_shifts`, `current_manpower`, `status`, `notes`) VALUES
            ('WSP-2026-001', 'prod-01', 'Rev C.1', 'New Product Launch Work Study, Line Balancing & Manpower Optimization', 'Toyota Production System (TPS) Standard Work Certification', 'Marcus Vance, PE', 'Eleanor Torres', 'David K. Henderson', '2026-10-01', '2026-11-15', 700, 'Line 4 (Alpha Progressive Board)', 36.00, 25200, 2, 6, 'Manpower Validation', 'Video time study complete. 180s work content validated across 5 stations with 36s cycle time.');");

        $pdo->exec("DELETE FROM `task_elements`;");
        $pdo->exec("INSERT INTO `task_elements` (`id`, `project_id`, `element_code`, `operation_name`, `work_description`, `sequence_order`, `workstation`, `tools`, `components`, `category`, `safety_considerations`, `quality_checks`, `performance_rating`, `standard_time`, `assigned_position`) VALUES
            ('elem-01', 'WSP-2026-001', 'ELE-01', 'Terminal Insertion into 48-Way ECU Housing', 'Select wire sub-bundle #1, insert 0.64mm terminals into cavities 1-12 with push-pull-push check.', 1, 'ST-01 Terminal Insertion 1', 'Magnifier Jig, Terminal Alignment Comb', 'Housing 90980-12543, 12x Terminals', 'Manual', 'Ergonomic hand-rest pad', 'Push-pull-push tactile check on 100% terminals', 1.00, 35.50, 'OP-01'),
            ('elem-02', 'WSP-2026-001', 'ELE-02', 'Branch Breakout & Insertion into 24-Way Fuse Box Connector', 'Route bundle #2 to fuse bracket jig, insert 8 power terminals and 4 relay signal wires, engage secondary lock.', 2, 'ST-02 Terminal Insertion 2', 'Fuse Housing Fixture, LED Pointer', '24-Way Fuse Box Shell, 12x Power Terminals', 'Manual', 'Correct pinch posture', 'Audible snap of secondary locking bar', 1.00, 35.80, 'OP-02'),
            ('elem-03', 'WSP-2026-001', 'ELE-03', 'Corrugated Tube Fitting & Main Trunk Spiral Taping', 'Apply split corrugated tube over trunk, secure Y-junction with 50% overlap PVC automotive tape.', 3, 'ST-03 Convoluted Tube & Taping', 'Pneumatic Spreader, Auto Tape Dispenser', 'Convoluted Tubing 13mm, PVC Tape', 'Manual', 'Safety blade dispenser', '50% tape overlap; zero exposed copper', 1.00, 36.00, 'OP-03'),
            ('elem-04', 'WSP-2026-001', 'ELE-04', 'Firewall Rubber Grommet Positioning & Body Clip Fitting', 'Slide rubber firewall grommet into position 420mm from branch, seat retention flange, install 6 barbed clips.', 4, 'ST-04 Grommet & Clip Assembly', 'Pneumatic Clip Seating Pliers, Dimension Guide', 'EPDM Firewall Grommet 65mm, 6x Clips', 'Manual', 'Anti-slip glove grip', 'Grommet location within +/- 3mm tolerance', 1.00, 35.20, 'OP-04'),
            ('elem-05', 'WSP-2026-001', 'ELE-05', 'Continuity & High-Pot Testing on Jig Board & Final Inspection', 'Dock 10 connectors into spring-loaded test modules, initiate 12.0s automated test cycle, apply green OK stamp.', 5, 'ST-05 Electrical Test & Final QA', 'Synor 5000 Test Board, Barcode Scanner', 'Pass Label, Green Torque Marker', 'Inspection', 'High-voltage interlock enclosure', 'Zero circuit opens/shorts; pass light green', 1.00, 35.50, 'OP-05');");

        $pdo->exec("DELETE FROM `operator_positions`;");
        $pdo->exec("INSERT INTO `operator_positions` (`id`, `position_number`, `position_name`, `workstation`, `target_cycle_time`, `required_skills`, `quality_gate`) VALUES
            ('pos-1', 'OP-01', 'Primary Sub-Assembly & ECU Connector Insertion', 'ST-01 Terminal Insertion 1', 36.00, 'Connector Terminal Insertion, Tactile Click Check', 'Push-pull-push terminal check (100%)'),
            ('pos-2', 'OP-02', 'Secondary Fuse Box & Relay Housing Insertion', 'ST-02 Terminal Insertion 2', 36.00, 'Heavy Power Insertion, Secondary Lock Bar Snap', 'Secondary lock audible snap confirmation'),
            ('pos-3', 'OP-03', 'Corrugated Tube Sleeving & Trunk Spiral Taping', 'ST-03 Convoluted Tube & Taping', 36.00, '50% Overlap Spiral Taping, Tube Sizing', 'Zero exposed wire insulation / 50% overlap gauge'),
            ('pos-4', 'OP-04', 'Bulkhead Grommet Seating & Body Clip Mounting', 'ST-04 Grommet & Clip Assembly', 36.00, 'Grommet Sealing Inspection, Barbed Clip Seating', '360° Grommet flange seal check'),
            ('pos-5', 'OP-05', 'High-Pot Electrical Testing & Final Packaging QA', 'ST-05 Electrical Test & Final QA', 36.00, 'Synor 5000 Tester Operation, Barcode Traceability', '100% Automated electrical test pass barcode');");

        $pdo->exec("DELETE FROM `manpower_plans`;");
        $pdo->exec("INSERT INTO `manpower_plans` (`id`, `project_id`, `net_available_time`, `required_quantity`, `takt_time`, `target_cycle_time`, `total_work_content`, `theoretical_min_operators`, `proposed_assigned_operators`, `line_efficiency_factor`, `status`, `approval_date`, `approved_by`, `assumptions`) VALUES
            ('mp-01', 'WSP-2026-001', 25200, 700, 36.00, 36.00, 178.60, 5, 5, 0.92, 'Validated', '2026-10-27', 'David K. Henderson (Plant Operations Director)', 'Net available time 25,200s (7h net after 1h break). Total work content 180s. Target cycle time 36.0s. 5 direct operators required. 1 floating relief operator.');");

        $pdo->exec("DELETE FROM `operator_skills`;");
        $pdo->exec("INSERT INTO `operator_skills` (`id`, `operator_id`, `operator_name`, `assigned_line`, `shift`, `workstation`, `skill_name`, `skill_level`, `training_status`, `qualification_date`) VALUES
            ('sk-01', 'OP-104', 'Elena Rostova', 'Line 4 (Alpha)', 'Shift 1 (Day)', 'ST-01 Terminal Insertion 1', '48-Way Sealed Connector Insertion', 'Level 4: Trainer/Expert', 'Qualified', '2026-09-25'),
            ('sk-02', 'OP-112', 'Kenji Sato', 'Line 4 (Alpha)', 'Shift 1 (Day)', 'ST-02 Terminal Insertion 2', 'Fuse Box Power Terminal Insertion', 'Level 3: Qualified', 'Qualified', '2026-09-28'),
            ('sk-03', 'OP-118', 'Maria Santos', 'Line 4 (Alpha)', 'Shift 1 (Day)', 'ST-03 Convoluted Tube & Taping', 'Automotive Spiral Taping', 'Level 3: Qualified', 'Qualified', '2026-09-29'),
            ('sk-04', 'OP-125', 'Ramon Diaz', 'Line 4 (Alpha)', 'Shift 1 (Day)', 'ST-04 Grommet & Clip Assembly', 'Bulkhead Grommet Flange Seating', 'Level 3: Qualified', 'Qualified', '2026-09-30'),
            ('sk-05', 'OP-130', 'Aisha Noor', 'Line 4 (Alpha)', 'Shift 1 (Day)', 'ST-05 Electrical Test & Final QA', 'Synor 5000 Tester Operation & QA', 'Level 4: Trainer/Expert', 'Qualified', '2026-09-22');");

        $pdo->exec("DELETE FROM `production_verifications`;");
        $pdo->exec("INSERT INTO `production_verifications` (`id`, `shift_date`, `shift_name`, `planned_output`, `actual_output`, `output_achievement_percent`, `target_cycle_time`, `actual_cycle_time`, `cycle_time_gap`, `planned_manpower`, `actual_manpower`, `downtime_minutes`, `supervisor_remarks`) VALUES
            ('pvr-01', '2026-10-27', 'Shift 1 (Day)', 700, 688, 98.30, 36.00, 36.40, 0.40, 5, 5, 8.50, 'Output 688 vs 700 within 98.3% achievement. 5-operator workload confirmed stable.'),
            ('pvr-02', '2026-10-28', 'Shift 1 (Day)', 700, 702, 100.30, 36.00, 35.90, -0.10, 5, 5, 4.00, 'Target exceeded (702 units). Cycle time 35.9s beats target 36.0s. Work study assumptions confirmed.');");

        $pdo->exec("DELETE FROM `audit_logs`;");
        $pdo->exec("INSERT INTO `audit_logs` (`id`, `timestamp`, `user_name`, `user_role`, `action`, `module`, `details`) VALUES
            ('log-01', '2026-10-28 14:30:15', 'Marcus Vance, PE', 'engineer', 'Manpower Plan Recalculated', 'Manpower Planning', 'Recalculated theoretical direct headcount = 5 operators based on 180s work content and 36s cycle time.'),
            ('log-02', '2026-10-27 16:45:00', 'David K. Henderson', 'approver', 'Workload Balance Approved', 'Workload Balancing', 'Approved 5-station operator balance. Max station time 36.0s, line balance efficiency 99.2%.');");
    }

    public static function resetDatabase(PDO $pdo): void {
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 0;");
        $pdo->exec("DROP TABLE IF EXISTS `production_verifications`, `standard_work_steps`, `standard_work_documents`, `operator_skills`, `workload_assignments`, `operator_positions`, `element_time_observations`, `task_elements`, `video_observations`, `video_files`, `manpower_plans`, `work_study_projects`, `products`, `users`, `audit_logs`;");
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 1;");
        self::ensureTablesExist($pdo);
        self::seedDemoData($pdo);
    }
}
