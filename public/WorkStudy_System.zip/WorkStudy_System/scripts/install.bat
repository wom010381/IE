@echo off
echo ========================================================
echo AWSMPS - Zero-SQL Setup Verification
echo ========================================================
echo Simply open http://localhost/WorkStudy_System/public/ (or http://localhost/awsmps/public/) in your browser!
echo The PHP code auto-creates the database, all columns, and tables automatically.
start http://localhost/WorkStudy_System/public/
pause
