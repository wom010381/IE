@echo off
echo Backing up AWSMPS Database...
set TIMESTAMP=%date:~10,4%-%date:~4,2%-%date:~7,2%
"C:\xampp\mysql\bin\mysqldump.exe" -u root awsmps > "..\storage\backups\awsmps_backup_%TIMESTAMP%.sql"
echo Backup complete!
pause
