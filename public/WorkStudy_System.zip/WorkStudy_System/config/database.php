<?php
/**
 * Database Configuration for AWSMPS
 * Default XAMPP settings: host 'localhost', port '3306', user 'root', password empty.
 */
define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_NAME', 'awsmps');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');
