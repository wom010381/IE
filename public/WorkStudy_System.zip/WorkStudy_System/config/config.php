<?php
/**
 * Application Settings
 */
define('APP_NAME', 'Automotive Work Study & Manpower Planning System');
define('APP_CODE', 'AWSMPS');
define('APP_VERSION', '1.0.1');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
