# AWSMPS - Zero-SQL Step-by-Step Installation Guide

### Prerequisites
1. Download and install **XAMPP for Windows** from Apache Friends.
2. In the XAMPP Control Panel, click **Start** next to **Apache** and **MySQL**.

---

### Step 1: Extract Files
Extract the contents of `WorkStudy_System.zip` to:
`C:\xampp\htdocs\WorkStudy_System\` or `C:\xampp\htdocs\awsmps\`

---

### Step 2: Open Application
Open your web browser and navigate to:
**`http://localhost/WorkStudy_System/public/`** (or `http://localhost/awsmps/public/`)

**The PHP code automatically configures the database, creates all missing columns, and seeds data!**

---

### Resetting to Fresh Factory Default
If you ever want to re-seed or reset your database, simply browse to:
`http://localhost/WorkStudy_System/public/?action=reset_database`
