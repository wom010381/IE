# Licenses and Dependencies

- **PHP**: PHP License v3.01
- **Bootstrap 5**: MIT License
- **Bootstrap Icons**: MIT License
- **MariaDB / MySQL**: GPL v2 / Commercial
