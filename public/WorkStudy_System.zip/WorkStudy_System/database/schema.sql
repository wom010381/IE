-- =====================================================================
-- AWSMPS: Automotive Work Study & Manpower Planning System
-- Schema Reference File (Auto-Provisioned directly by PHP code!)
-- =====================================================================
CREATE DATABASE IF NOT EXISTS `awsmps` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `awsmps`;

CREATE TABLE IF NOT EXISTS `products` (
  `id` VARCHAR(36) PRIMARY KEY,
  `model_number` VARCHAR(100) NOT NULL,
  `product_name` VARCHAR(200) NOT NULL,
  `part_number` VARCHAR(100) NOT NULL,
  `revision` VARCHAR(30) NOT NULL,
  `customer` VARCHAR(150) NOT NULL,
  `vehicle_model` VARCHAR(150) NOT NULL,
  `circuit_count` INT NOT NULL DEFAULT 0,
  `status` ENUM('Draft', 'Active', 'On Hold', 'Obsolete') DEFAULT 'Active',
  UNIQUE KEY `uk_product_rev` (`model_number`, `revision`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `task_elements` (
  `id` VARCHAR(36) PRIMARY KEY,
  `project_id` VARCHAR(36) NOT NULL,
  `element_code` VARCHAR(50) NOT NULL,
  `operation_name` VARCHAR(200) NOT NULL,
  `work_description` TEXT NOT NULL,
  `sequence_order` INT NOT NULL DEFAULT 1,
  `workstation` VARCHAR(100) NOT NULL,
  `standard_time` DECIMAL(8,2) NOT NULL DEFAULT 36.00,
  `assigned_position` VARCHAR(50) DEFAULT 'OP-01'
) ENGINE=InnoDB;
