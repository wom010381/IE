-- =====================================================================
-- AWSMPS: Demonstration Seed Data (Auto-Provisioned directly by PHP code!)
-- =====================================================================
USE `awsmps`;
INSERT INTO `products` (`id`, `model_number`, `product_name`, `part_number`, `revision`, `customer`, `vehicle_model`, `circuit_count`, `status`) VALUES
('prod-01', 'WH-ENG-8402', 'Engine Main Wiring Harness (Hybrid V6)', '82111-42K80', 'Rev C.1', 'Toyota Global / TNGA-K', 'Camry HEV 2026', 74, 'Active');
