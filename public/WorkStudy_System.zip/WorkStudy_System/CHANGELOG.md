# Changelog - AWSMPS

## [1.0.1] - 2026-10-28
### Fixed
- Added self-healing schema migration in Database.php to automatically detect and add `sequence_order`, `standard_time`, and other columns if an older database table already existed.
- Added defensive query wrapper in `public/index.php` to prevent SQL column-not-found fatal errors.
