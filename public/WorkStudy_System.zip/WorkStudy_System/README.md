# Automotive Work Study & Manpower Planning System (AWSMPS)
Version 1.0 - Automotive Wiring Harness Industrial Engineering Platform
**ZERO-SQL-EDIT AUTOMATIC INSTALLATION & AUTO-MIGRATING ENGINE**

## Overview
AWSMPS is a specialized engineering web application designed for automotive wiring harness manufacturing plants. It provides end-to-end work study management, video observation time study, standard work documentation (SOP/SWI), line balancing, constraint validation, and validated manpower planning.

## Zero-SQL-Edit & Self-Healing Database Feature
**You do not need to edit or import any SQL files.**
All table structures, foreign keys, indexes, columns, and demonstration datasets are incorporated directly into the application PHP code.
- Automatic creation of the `awsmps` database if it does not exist.
- Automatic column check: If any column (e.g. `sequence_order`, `standard_time`, `assigned_position`) is missing from an existing table, the PHP engine automatically executes `ALTER TABLE` migrations on the fly.
- Automatic seeding of all sample models (Toyota WH-ENG-8402 74-circuit harness, 180s work content, 36s cycle time, 5 balanced operators).
- One-click reset: `http://localhost/awsmps/public/?action=reset_database`

## System Requirements
- Windows PC running **XAMPP 8.1+** (Apache 2.4, MariaDB 10.4+ / MySQL 8.0, PHP 8.1+)
- Modern web browser (Chrome, Edge, Firefox)
- Network: Works 100% offline inside internal plant LAN without internet access.
